# M10 güncel giriş noktası

**M10 için [README_M10.md](README_M10.md) ve [M10_ACCEPTANCE.md](M10_ACCEPTANCE.md) dosyalarını okuyun.** Aşağıdaki bölüm önceki M09 paketinin arşivsel açıklamasıdır.

---

# FreyaTTS M08 — Local Operator Console & Pronunciation Review UI

**Kabul sınırı:** M01–M08, çevrimdışı ve tamamen sentetik. Gerçek TTS/STT/LLM/telephony ve harici ağ çağrısı yapılmaz. M07'ye kadar 332 otomatik regresyon korunmuştur.

## Windows kurulum (internetsiz, stdlib tabanlı)

```powershell
py -3.11 -m venv .venv
.\scripts\check_m08.ps1 -Python ".\.venv\Scripts\python.exe"
.\scripts\start_m08.ps1 -Python ".\.venv\Scripts\python.exe" -Port 8765
```

Tarayıcı: `http://127.0.0.1:8765` (yalnızca aynı Windows bilgisayarında). Windows/Python 3.11 henüz fiziksel olarak doğrulanmadı. Linux/Python 3.13 üzerinde doğrulandı.

## Genel bakış

- `Genel bakış`: gerçek M07 mock adapter health, 4 hizmet, oturum sayısı ve olaylar.
- `Oturumlar`: `+ Yeni sentetik oturum` düğmesiyle M02 üzerinden state başlatılır. `STT: Son transkript` düğmesi **gerçek metin almaz**, opak `m08_synthetic_ref_*` oluşturur. `LLM: Yanıt hazır` M07 sahte TTS efektini tetikler.
- `VAD: Konuşma başladı`, `SPEAKING` sırasında barge-in yapar. `FAKE ACK` seçilmeden `INTERRUPTING` durumu bitmez. `+1,6 sn` sentetik zaman atlatmak flush timeout'u sınar.
- `Telaffuz inceleme`: mevcut 3 A01-YT kaynak ve 320 golden metin vakası. 0 gerçek klip / 0 insan tarafından onaylanmış telaffuz olduğunda onay kuyruğu boştur. Operatör kararları `var/m08_reviews.sqlite3` overlay'e yazılır; A01-YT'nin SQLite dosyası değişmez.
- `Olay günlüğü`: en fazla son 160 PII içermeyen kodlu olay.

## API ve dokümantasyon

- `GET /api/bootstrap` → CSRF token; `GET /api/snapshot` → sadece metaveri ve bilinen sentetik fixtures; `POST /api/action` → `X-Console-CSRF` ile onaylı mock komutlar.
- `docs/35_M08_OPERATOR_CONSOLE_MIMARISI.md`, `docs/36_M08_KABUL_VE_M09_DEVIR.md`, `docs/37_M09_AI_AGENT_GOREVI.md`.
- Önceki M01–M07 mimari/rapor dosyaları ve test verileri korunur.

## Üretim için sınırlamalar

Bu panel yetkilendirme, TLS, kimlik doğrulama, çoklu kullanıcı yönetimi ve kalıcı çağrı audit güvencesi içermez. Loopback dışına çıkarılmamalıdır. Gerçek ses dosyası işleme, Freya inference, telefon kabulü, RTF, MOS/WER/CER testleri en son M11 aşamasına bırakılmıştır.

---

# M09 — Sentetik Uçtan Uca Entegrasyon

M01–M08 bütün kodu ve verisi korunarak `automotive_voice.e2e` paketi eklenmiştir. M08 yerel konsolda **M09 Senaryolar** sekmesi bulunur. Çalıştırıcı gerçek M02/M03/M04/M05/M06/M07 modüllerini aynı oturum otoritesinde kullanır. Sadece fake CRM/booking/STT/LLM/TTS/telephony; **hiç gerçek ses veya harici servis yoktur**.

Windows, ZIP açıldıktan sonra:

```powershell
py -3.11 -m venv .venv
.\scripts\check_m09.ps1 -Python ".\.venv\Scripts\python.exe"
.\scripts\start_m08.ps1 -Python ".\.venv\Scripts\python.exe" -Port 8765
```

Tarayıcı: `http://127.0.0.1:8765` > **M09 Senaryolar**. Her düğme tek bir sentetik senaryoyu çalıştırır; karar kontrol listesi ve PII içermeyen olay izi görünür. Alternatif olarak `python -m automotive_voice.m09_demo` ile tüm senaryolar JSON biçiminde çalıştırılabilir. Testler için yalnızca Python stdlib gerekir; şema doğrulaması istenirse `jsonschema` ekstra bağımlılığı kullanılabilir.

**Kabul:** M09 iş kuralları, state/transport ve senaryo kontrolleri mock PASS; gerçek ses çıkışı, özelleştirilmiş telaffuz sözlüğü, kalıcı outbox ve production readiness HOLD. Açık metin üretim kusurlarını `docs/42_M09_KALAN_RISKLER.md` açıklıyor.
