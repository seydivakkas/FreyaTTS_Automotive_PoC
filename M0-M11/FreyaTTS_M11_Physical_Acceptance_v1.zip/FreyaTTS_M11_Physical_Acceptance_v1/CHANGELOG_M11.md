# M11 v1 değişiklik özeti

- M10 ana kodunun üzerine `automotive_voice.m11` eklendi, eski modüllere müdahale edilmedi.
- Kanıt bütünlüğü, PASS/FAIL/HOLD ve fail-closed fiziksel kabul kapıları oluşturuldu.
- Gerçek Windows/CUDA/model preflight; kaynak hash raporu eklendi.
- Yerel Freya gerçek WAV çıkarım aracı (`tts`, yalnız açık fiziksel opt-in), 320 A/B manifest ve insan ses denetimi (`voice-review`) eklendi.
- Etiketli STT WAV dosyaları için WER/CER, gerçek ses codec örnekleri için FFmpeg paketleme, Asterisk canlı olay izi ve bağımsız gözlem doğrulama sözleşmeleri eklendi.
- A01-YT ilk 50 gerçek klip inceleme/izin koşulları eklendi; hiçbir YouTube ses kaydı üretilmedi veya indirilmedi.
- PowerShell M11 komutları ve çevrimdışı JSON/HTML rapor eklendi.
- M01–M10 435 test korunurken M11 için 25 yeni test eklendi: toplam 460/460.
- Fiziksel kabul sonucu, gerçek donanım/veri olmadığı için **HOLD**. Production readiness false.
