# FreyaTTS Automotive — M10 Real Adapter Readiness & Resilience (Dry Run)

Bu depo M01–M09'u kapsayan **tek kod tabanının** M10 devamıdır. Yeni modüller `resilience/durable.py`, `readiness/contracts.py`, `readiness/presentation.py` ve `m10_demo.py`. Son aşamadaki gerçek ses/YouTube/telefon testleri bu pakette yürütülmez.

## Windows/PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[validation]"
.\scripts\check_m10.ps1 -Python ".\.venv\Scripts\python.exe"
.\scripts\start_m08.ps1 -Python ".\.venv\Scripts\python.exe" -Port 8765
```

Operatör paneli `http://127.0.0.1:8765` → **M10 Hazırlık**. M10 dry-run 20 senaryonun ve SQLite restart testinin raporunu `data/reports/m10_local_dry_run.json` dosyasına yazar.

Yalnızca komut satırından çalıştırmak için:

```powershell
$env:PYTHONPATH = "src"
.\.venv\Scripts\python.exe -m automotive_voice.m10_demo --output data\reports\m10_local_dry_run.json
```

Komut gerçek modele/telefona bağlanmaz, ses dosyası üretmez. `README.md` eski aşamaların arşivsel tarihçesidir; bu belge M10 için güncel giriş noktasıdır.

## Belgeler

- `docs/44_M10_DURABLE_OUTBOX_VE_RECOVERY.md`
- `docs/45_M10_TEXT_PRESENTATION_AND_ADAPTERS.md`
- `docs/46_M10_GUVENLIK_RISK_VE_HOLD.md`
- `docs/47_M10_M11_DEVIR_VE_AGENT_GOREVI.md`
- `M10_ACCEPTANCE.md`

Üretim hazır sayılmaz. Geçerli `production_ready` çıktısı daima `false`.
