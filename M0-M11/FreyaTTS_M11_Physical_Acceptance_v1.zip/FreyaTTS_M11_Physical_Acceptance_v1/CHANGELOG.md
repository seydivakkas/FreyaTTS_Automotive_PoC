# M10 — Resilience & Readiness Dry Run v1

- M01 oturum geçişleri + EventEnvelope, SQLite WAL FULL transaction; recover fail-closed, FIFO event ACK.
- M03 yanıt metni için sesle okunabilir güvenli speech sunumu; orijinal display korunur.
- M10 offline Freya/STT/LLM/PBX config denetimi, tüm gerçek aktivasyonlar kapalı.
- M08 UI yeni M10 Hazırlık sekmesi; eski UI simülasyonu hâlâ volatil.
- 20 sentetik senaryo SQLite oturum otoritesiyle yeniden koşuldu; 10 eski review engeli M10 sunumuyla 0.
- 435 otomatik test; 320 cümlelik golden fixture SHA korunuyor; gerçek ses yok.

---

# M08 değişiklik günlüğü

- M07 paketinin tamamı üzerine, eski Python kaynaklarını değiştirmeden `operator/` eklenmiştir.
- Offline localhost HTTP konsolu, vanilla JS ve responsive Türkçe arayüz eklendi.
- M02 reducer ile sentetik kontrol, M07 health, M06 FakeTransport flush ve XOFF/XON görselleştirildi.
- A01-YT read-only kaynak adapteri, ayrı SQLite review overlay ve kanıtlı onay kapısı eklendi.
- 320 eski metin vakası ve M04 karşılaştırması görünür hâle getirildi.
- M08 güvenlik ve sözleşme testleri, PowerShell betikleri, M09 devir belgeleri eklendi.
- Gerçek ses / PBX / YouTube medya / GPU / model çalıştırılmadı.
