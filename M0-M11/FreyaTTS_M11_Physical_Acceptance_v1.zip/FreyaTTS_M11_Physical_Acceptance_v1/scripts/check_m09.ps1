param([string]$Python = "python")
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
$env:PYTHONUTF8 = "1"
$env:PYTHONPATH = (Join-Path (Get-Location) "src")
Write-Host "M09 offline-only synthetic E2E checks (no audio, calls, external network)"
& $Python -m unittest discover -s tests -q
if ($LASTEXITCODE -ne 0) { throw "M01-M09 unit regression failed" }
& $Python -m automotive_voice.m09_demo
if ($LASTEXITCODE -ne 0) { throw "M09 scenario suite failed" }
Write-Host "M09 mock-only acceptance PASS; production and real-audio gates remain HOLD"
