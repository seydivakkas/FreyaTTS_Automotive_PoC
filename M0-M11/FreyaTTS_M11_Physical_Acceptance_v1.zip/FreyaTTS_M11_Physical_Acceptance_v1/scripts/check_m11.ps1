param(
  [string]$Python = "python",
  [string]$ModelDir = "",
  [string]$FreyaCheckout = ""
)
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
$env:PYTHONPATH = "src"
& $Python -m unittest discover -s tests -q
if ($LASTEXITCODE -ne 0) { throw "M01-M11 unittest FAILED" }
& $Python -m automotive_voice.m11 legacy
if ($LASTEXITCODE -ne 0) { throw "M11 legacy regression FAILED" }
$extra = @()
if ($ModelDir) { $extra += @("--model-dir",$ModelDir) }
if ($FreyaCheckout) { $extra += @("--freya-checkout",$FreyaCheckout) }
& $Python -m automotive_voice.m11 preflight @extra
if ($LASTEXITCODE -ne 0) { throw "M11 preflight ERROR" }
& $Python -m automotive_voice.m11 report
if ($LASTEXITCODE -ne 0) { throw "M11 report ERROR" }
Write-Host "M11 SOFTWARE VALIDATION FINISHED; PHYSICAL ACCEPTANCE REMAINS HOLD UNTIL EVIDENCED"
