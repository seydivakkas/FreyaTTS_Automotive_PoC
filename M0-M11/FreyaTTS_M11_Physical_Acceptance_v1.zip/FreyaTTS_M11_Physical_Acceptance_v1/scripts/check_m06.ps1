param([string]$Python = "python")
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
    $env:PYTHONPATH = Join-Path $root 'src'
    & $Python -m unittest discover -s tests -v
    if ($LASTEXITCODE -ne 0) { throw 'M01-M06 regression failed' }
    & $Python -m automotive_voice.m05_report
    if ($LASTEXITCODE -ne 0) { throw 'M05 golden set check failed' }
    & $Python -m automotive_voice.m06_demo
    if ($LASTEXITCODE -ne 0) { throw 'M06 mock metadata demo failed' }
} finally {
    Pop-Location
}
