param([string]$Python = "python")
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
$env:PYTHONUTF8 = "1"
$env:PYTHONPATH = (Join-Path (Get-Location) "src")
Write-Host "M08 mock-only acceptance (no models/audio/phone)"
& $Python -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { throw "M08 unit tests failed: $LASTEXITCODE" }
& $Python -m automotive_voice.m07_demo
if ($LASTEXITCODE -ne 0) { throw "M07 synthetic demo failed: $LASTEXITCODE" }
Write-Host "PASS: M01-M08 regression and synthetic M07 demo"
