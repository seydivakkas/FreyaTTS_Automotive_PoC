$ErrorActionPreference = 'Stop'
$env:PYTHONPATH = 'src'
if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3.11 -m unittest discover -s tests -v
    if ($LASTEXITCODE -ne 0) { throw 'M01/M02 automated test suite failed' }
    & py -3.11 -m automotive_voice.m02_demo
    if ($LASTEXITCODE -ne 0) { throw 'M02 simulation failed' }
} else {
    & python -m unittest discover -s tests -v
    if ($LASTEXITCODE -ne 0) { throw 'M01/M02 automated test suite failed' }
    & python -m automotive_voice.m02_demo
    if ($LASTEXITCODE -ne 0) { throw 'M02 simulation failed' }
}
Write-Host 'M02 mock acceptance passed. Real audio/PBX acceptance remains deferred.'
