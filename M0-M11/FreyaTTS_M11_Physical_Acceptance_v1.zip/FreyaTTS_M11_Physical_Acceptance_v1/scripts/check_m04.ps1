param(
    [string]$Python = "python"
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
    $env:PYTHONPATH = Join-Path $root 'src'
    & $Python -m unittest discover -s tests -v
    if ($LASTEXITCODE -ne 0) { throw 'M01-M04 test suite failed' }
    & $Python -m automotive_voice.m04_report
    if ($LASTEXITCODE -ne 0) { throw 'M04 320-case comparison failed' }
} finally {
    Pop-Location
}
