param([string]$Python="python")
$ErrorActionPreference="Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
$env:PYTHONPATH="src"
& $Python -m automotive_voice.m11 report
if ($LASTEXITCODE -ne 0) { throw "M11 acceptance report failed" }
