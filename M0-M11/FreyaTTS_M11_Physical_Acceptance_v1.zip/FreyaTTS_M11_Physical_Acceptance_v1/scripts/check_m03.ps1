$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
    if (Test-Path '.venv\Scripts\python.exe') { $python = '.\.venv\Scripts\python.exe' }
    else { $python = 'python' }
    $env:PYTHONPATH = (Join-Path $root 'src')
    & $python -m unittest discover -s tests -v
    if ($LASTEXITCODE -ne 0) { throw 'Unit tests FAILED' }
    & $python -m automotive_voice.m03_demo
    if ($LASTEXITCODE -ne 0) { throw 'M03 demo FAILED' }
    Write-Host 'M03 mock acceptance PASS. Real audio, GPU, SIP and phone NOT tested.'
} finally { Pop-Location }
