param(
  [string]$Python = "python",
  [string]$Output = "data\reports\m10_local_dry_run.json"
)
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
$env:PYTHONPATH = "src"
& $Python -m unittest discover -s tests -q
if ($LASTEXITCODE -ne 0) { throw "M01-M10 tests FAILED" }
& $Python -m automotive_voice.m10_demo --output $Output
if ($LASTEXITCODE -ne 0) { throw "M10 dry-run FAILED" }
Write-Host "M10 DRY RUN PASS - no real adapters, no audio"
