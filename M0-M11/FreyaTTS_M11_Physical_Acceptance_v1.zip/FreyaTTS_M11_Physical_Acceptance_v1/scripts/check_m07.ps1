param([string]$Python = "python")
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
    $env:PYTHONPATH = Join-Path $root 'src'
    & $Python -m unittest discover -s tests -v
    if ($LASTEXITCODE -ne 0) { throw 'M01-M07 regression failed' }
    & $Python -m automotive_voice.m05_report
    if ($LASTEXITCODE -ne 0) { throw 'Legacy M05 golden text checks failed' }
    & $Python -m automotive_voice.m06_demo
    if ($LASTEXITCODE -ne 0) { throw 'M06 metadata demo failed' }
    & $Python -m automotive_voice.m07_demo
    if ($LASTEXITCODE -ne 0) { throw 'M07 lifecycle/streaming demo failed' }
} finally {
    Pop-Location
}
