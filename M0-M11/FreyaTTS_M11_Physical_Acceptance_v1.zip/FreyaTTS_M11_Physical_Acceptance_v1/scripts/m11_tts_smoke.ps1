param(
  [Parameter(Mandatory=$true)][string]$ModelDir,
  [Parameter(Mandatory=$true)][string]$FreyaCheckout,
  [string]$Python = ".\.venv\Scripts\python.exe",
  [switch]$Full
)
$ErrorActionPreference="Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
$env:PYTHONPATH="src"
$mode=if ($Full) { "full" } else { "smoke" }
& $Python -m automotive_voice.m11 tts --enable-physical --model-dir $ModelDir --freya-checkout $FreyaCheckout --mode $mode --seed 9 --steps 32
if ($LASTEXITCODE -ne 0) { throw "M11 Freya inference FAILED" }
& $Python -m automotive_voice.m11 report
