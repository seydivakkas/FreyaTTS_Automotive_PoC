param([string]$Python = "python", [int]$Port = 8765)
$ErrorActionPreference = "Stop"
if ($Port -lt 1 -or $Port -gt 65535) { throw "Invalid localhost port" }
Set-Location (Split-Path -Parent $PSScriptRoot)
$env:PYTHONUTF8 = "1"
$env:PYTHONPATH = (Join-Path (Get-Location) "src")
Write-Host "M08 OFFLINE MOCK operator console: http://127.0.0.1:$Port"
Write-Host "Real TTS, microphone, SIP, Asterisk and external networking are DISABLED."
& $Python -m automotive_voice.operator --port $Port
if ($LASTEXITCODE -ne 0) { throw "M08 server failed: $LASTEXITCODE" }
