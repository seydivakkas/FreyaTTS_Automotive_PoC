# FreyaTTS — M11 Physical Acceptance & Real Voice Validation

**Kanonik devam:** M10'daki kod, dosya yapısı, 320 golden cümle, SQLite dayanıklılık modülleri ve M01–M10 regresyonları korunmuştur. Yeni kaynak: `src/automotive_voice/m11/`. Üretim hazır değildir.

## Mevcut sonuç

- M10 baz testi: **435/435 PASS** (yeni M11 testlerinden önce).
- M11 bu ortamda gerçek model çalıştırmadı: sistem Linux/Python 3.13; Windows/Edge, RTX 4070, gerçek PBX, ses dosyaları ve model ağırlıkları burada yok.
- `preflight` ve `report` M11 fiziksel kabulünü **HOLD** olarak kaydeder. `legacy` gerçek regresyon logunu SHA-256 ile kanıtlı PASS olarak kaydeder.
- M11 `tts`, `stt`, `codec`, `a01yt`, `pbx` ayrı komutlardır; dış servis bağlantısı veya medya indirme varsayılan olarak yapılmaz. `--enable-physical` istenen gerçek testlerde açıkça kullanılır.
- M10'un başka ortama kurulmuş ve test edilmiş olması M11'in fiziksel kabulü değildir.

## Windows başlangıç

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[validation]"
.\scripts\check_m11.ps1 -Python ".\.venv\Scripts\python.exe"
.\scripts\m11_report.ps1 -Python ".\.venv\Scripts\python.exe"
```

Kayıtlar `data/m11/results/*.json` ve `data/m11/M11_ACCEPTANCE.json`, yerel görsel rapor ise `data/m11/M11_ACCEPTANCE.html` içindedir.

İsteğe bağlı gerçek Freya smoke için `scripts/m11_tts_smoke.ps1`, kabul protokolü için `docs/48_M11_FIZIKSEL_KABUL_PLANI.md`, tüm komutlar için `docs/49_M11_WINDOWS_ADIM_ADIM.md`.

## Kabul ilkesi

`PASS` sadece kanıta dayalıdır. Eksik cihaz, dosya, klip, insan dinleme onayı veya gerçek PBX izinde `HOLD` verilir. Sahte adaptör ACK'i ile gerçek PBX kabulü yapılamaz. M11 fiziksel kabulü PASS olsa bile güvenlik, ölçek ve üretim onayı ayrı karardır.

M11 hiçbir şekilde YouTube'dan izinsiz/otomatik ses indirme veya Freya ses profilini değiştirme girişiminde bulunmaz. A01-YT izin kayıtları kaynak bazlı olarak korunur; onaylı telaffuz kuralı hâlen sıfırdır.
